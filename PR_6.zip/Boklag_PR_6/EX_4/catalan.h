#ifndef CATALAN_H
#define CATALAN_H

unsigned long long calculate_catalan(int n);

#endif
