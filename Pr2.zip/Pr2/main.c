#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_SEQUENCE_LENGTH 10
#define NUM_POSSIBLE_VALUES 10

void printRules() {
    printf("Welcome to the 'One-Armed Bandit' game!\n");
    printf("Game Rules:\n");
    printf("- You have a certain number of coins.\n");
    printf("- You place a bet and enter the length of the sequence of numbers.\n");
    printf("- If the sequence contains at least one 7, you win your bet back.\n");
    printf("- If all numbers in the sequence are the same, you win more.\n");
    printf("- If at least one-third of the numbers are the same, you win your bet back.\n");
    printf("Wins:\n");
    printf("- If there is at least one 7: you get your bet back.\n");
    printf("- If all numbers are the same: your bet is doubled.\n");
    printf("- If at least one-third of the numbers are the same: you get your bet back.\n");
}

void printSequence(int sequence[], int length) {
    printf("Sequence: ");
    for (int i = 0; i < length; i++) {
        printf("%d ", sequence[i]);
    }
    printf("\n");
}

int generateRandomNumber(int maxValue) {
    return rand() % maxValue;
}

void generateSequence(int sequence[], int length) {
    for (int i = 0; i < length; i++) {
        sequence[i] = generateRandomNumber(NUM_POSSIBLE_VALUES);
    }
}

int checkForSevens(int sequence[], int length) {
    for (int i = 0; i < length; i++) {
        if (sequence[i] == 7) {
            return 1;
        }
    }
    return 0;
}

int checkForAllSame(int sequence[], int length, int* win) {
    int frequency[NUM_POSSIBLE_VALUES] = {0};

    for (int i = 0; i < length; i++) {
        frequency[sequence[i]]++;
    }

    for (int i = 0; i < NUM_POSSIBLE_VALUES; i++) {
        if (frequency[i] == length) {
            *win = (i == 7) ? *win * 3 : *win * 2;
            return 1;
        }
    }
    return 0;
}

int checkForOneThirdSame(int sequence[], int length, int* win) {
    int frequency[NUM_POSSIBLE_VALUES] = {0};

    for (int i = 0; i < length; i++) {
        frequency[sequence[i]]++;
    }

    for (int i = 0; i < NUM_POSSIBLE_VALUES; i++) {
        if (frequency[i] >= (length + 2) / 3) {
            if (*win == 0) {
                *win = *win + *win;
                return 1;
            }
        }
    }
    return 0;
}

int main() {
    srand(time(NULL));
    int coins = 100;

    printRules();

    while (coins > 0) {
        int bet, win = 0;
        printf("You have %d coins\n", coins);
        printf("Enter your bet (0 to exit): ");
        scanf("%d", &bet);

        if (bet == 0)
            break;
        if (bet > coins) {
            printf("You cannot bet more than you have!\n");
            continue;
        }

        int length;
        printf("Enter the length of the sequence: ");
        scanf("%d", &length);

        if (length > MAX_SEQUENCE_LENGTH || length <= 0) {
            printf("Invalid sequence length. It should be between 1 and %d.\n", MAX_SEQUENCE_LENGTH);
            continue;
        }

        int sequence[MAX_SEQUENCE_LENGTH];

        generateSequence(sequence, length);

        printSequence(sequence, length);

        if (checkForSevens(sequence, length)) {
            win = bet;
        }

        if (checkForAllSame(sequence, length, &win)) {
            printf("All numbers are the same! Win: %d coins\n", win);
        }

        if (checkForOneThirdSame(sequence, length, &win)) {
            printf("At least one-third of the numbers are the same! Win: %d coins\n", win);
        }

        coins = coins - bet + win;

        if (win == 0) {
            printf("Sorry! You lost your bet!\n");
        } else {
            printf("Congratulations! You won %d coins\n", win);
        }
    }

    printf("Game over!\n");
    printf("You have %d coins left\n", coins);

    return 0;
}
