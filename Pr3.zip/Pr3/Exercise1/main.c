#include <stdio.h>
#include <stdlib.h>

struct ArrayList {
    int *array;
    int size;
    int capacity;
};

struct ArrayList* createArrayList() {
    struct ArrayList* list = (struct ArrayList*)malloc(sizeof(struct ArrayList));
    if (list == NULL) {
        return NULL;
    }
    list->size = 0;
    list->capacity = 10; // Initial list capacity
    list->array = (int*)malloc(list->capacity * sizeof(int));
    if (list->array == NULL) {
        free(list);
        return NULL;
    }
    return list;
}

void ensureCapacity(struct ArrayList* list, int minCapacity) {
    if (minCapacity > list->capacity) {
        while (list->capacity < minCapacity) {
            list->capacity *= 2;
        }
        list->array = (int*)realloc(list->array, list->capacity * sizeof(int));
    }
}

void add(struct ArrayList* list, int item) {
    ensureCapacity(list, list->size + 1);
    list->array[list->size] = item;
    list->size++;
}

void insert(struct ArrayList* list, int index, int item) {
    if (index >= 0 && index <= list->size) {
        ensureCapacity(list, list->size + 1);
        for (int i = list->size; i > index; i--) {
            list->array[i] = list->array[i - 1];
        }
        list->array[index] = item;
        list->size++;
    }
}

int size(struct ArrayList* list) {
    return list->size;
}

void removeу(struct ArrayList* list, int index) {
    if (index >= 0 && index < list->size) {
        for (int i = index; i < list->size - 1; i++) {
            list->array[i] = list->array[i + 1];
        }
        list->size--;
    }
}

void set(struct ArrayList* list, int index, int item) {
    if (index >= 0 && index < list->size) {
        list->array[index] = item;
    }
}

int get(struct ArrayList* list, int index) {
    if (index >= 0 && index < list->size) {
        return list->array[index];
    }
    return -1;
}

void freeArrayList(struct ArrayList* list) {
    free(list->array);
    free(list);
}

int main() {
    struct ArrayList* list = createArrayList();
    add(list, 1);
    add(list, 2);
    add(list, 3);
    printf("List size: %d\n", size(list));
    printf("List: ");
    for (int i = 0; i < size(list); i++) {
        printf("%d ", get(list, i));
    }
    printf("\n");

    insert(list, 1, 4);
    insert(list, 2, 5);
    printf("List after insertion: ");
    for (int i = 0; i < size(list); i++) {
        printf("%d ", get(list, i));
    }
    printf("\n");

    printf("Element at position 2: %d\n", get(list, 2));
    set(list, 0, 10);
    printf("List after set element: ");
    for (int i = 0; i < size(list); i++) {
        printf("%d ", get(list, i));
    }
    printf("\n");

    removeу(list, 2);
    printf("List after removing: ");
    for (int i = 0; i < size(list); i++) {
        printf("%d ", get(list, i));
    }
    printf("\n");
    freeArrayList(list);
    return 0;
}
